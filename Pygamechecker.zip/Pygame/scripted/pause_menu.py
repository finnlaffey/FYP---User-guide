import pygame
from sys import exit

def draw_rounded_rect(surface, rect, color, radius=15):
    shape_surf = pygame.Surface(pygame.Rect(rect).size, pygame.SRCALPHA)
    pygame.draw.rect(shape_surf, color, shape_surf.get_rect(), border_radius=radius)
    surface.blit(shape_surf, rect)

def handle_pause_selection(selection, max_levels):
    if selection < max_levels:
        return selection  # level index
    elif selection == max_levels:
        return True  # resume
    elif selection == max_levels + 1:
        return 'workload'  # new option
    else:
        pygame.quit()
        exit()

def pause_menu(display, current_selection, max_levels):
    pygame.font.init()
    menu_options = max_levels + 3  # Load Levels + Resume + Workload Display + Exit
    font = pygame.font.SysFont("Arial", 36)
    title_font = pygame.font.SysFont("Arial", 48, bold=True)
    clock = pygame.time.Clock()

    while True:
        display_width, display_height = display.get_size()

        # Dim background
        overlay = pygame.Surface(display.get_size(), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        display.blit(overlay, (0, 0))

        # Menu box
        menu_width, menu_height = 500, 100 + 60 * menu_options
        menu_x = (display_width - menu_width) // 2
        menu_y = (display_height - menu_height) // 2
        menu_rect = pygame.Rect(menu_x, menu_y, menu_width, menu_height)

        draw_rounded_rect(display, menu_rect.move(5, 5), (0, 0, 0, 100), radius=20)
        draw_rounded_rect(display, menu_rect, (40, 40, 60), radius=20)

        # Title
        title_surf = title_font.render("Pause Menu", True, (255, 255, 255))
        display.blit(title_surf, (menu_x + (menu_width - title_surf.get_width()) // 2, menu_y + 20))

        # Menu items
        for i in range(menu_options):
            if i < max_levels:
                label = f"Load Level {i}"
            elif i == max_levels:
                label = "Resume"
            elif i == max_levels + 1:
                label = "Workload Display"
            else:
                label = "Exit Game"

            is_selected = (i == current_selection)
            color = (255, 255, 255) if not is_selected else (40, 40, 60)
            bg_color = (255, 255, 100) if is_selected else None

            item_rect = pygame.Rect(menu_x + 40, menu_y + 100 + i * 60, menu_width - 80, 50)
            if bg_color:
                draw_rounded_rect(display, item_rect, bg_color, radius=12)

            text_surf = font.render(label, True, color)
            text_rect = text_surf.get_rect(center=item_rect.center)
            display.blit(text_surf, text_rect)

        pygame.display.update()

        # Input handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    current_selection = (current_selection - 1) % menu_options
                elif event.key == pygame.K_DOWN:
                    current_selection = (current_selection + 1) % menu_options
                elif event.key == pygame.K_RETURN:
                    return handle_pause_selection(current_selection, max_levels)

            if event.type == pygame.JOYBUTTONDOWN:
                if event.button == 0:  # A
                    return handle_pause_selection(current_selection, max_levels)
                if event.button == 1:  # B
                    if current_selection == max_levels:
                        return True
                if event.button == 7:  # Start
                    return True

            if event.type == pygame.JOYHATMOTION:
                dx, dy = event.value
                if dy == 1:  # Up
                    current_selection = (current_selection - 1) % menu_options
                elif dy == -1:  # Down
                    current_selection = (current_selection + 1) % menu_options

        clock.tick(15)
