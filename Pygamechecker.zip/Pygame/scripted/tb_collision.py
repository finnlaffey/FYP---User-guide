import pygame
import json 


def check_rect_circle_collision(rect, circle_x, circle_y, circle_radius):

    closest_x = max(rect.left, min(circle_x, rect.right))
    closest_y = max(rect.top, min(circle_y, rect.bottom))
    distance_x = circle_x - closest_x
    distance_y = circle_y - closest_y
    distance_squared = (distance_x**2) + (distance_y**2)
    return distance_squared < (circle_radius**2)