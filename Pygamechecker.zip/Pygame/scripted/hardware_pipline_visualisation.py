import pygame
import random
import sys
import math

def script_driven_visualization():
    """
    Visualizes a Python script calling a parallel hardware process (FPGA)
    which then writes to a framebuffer.
    """
    pygame.init()
    pygame.font.init()

    # --- Screen and Font Configuration ---
    w, h = 1280, 720
    display = pygame.display.set_mode((w, h))
    pygame.display.set_caption("Code-Driven Parallel Pipeline")
    clock = pygame.time.Clock()
    code_font = pygame.font.SysFont("Consolas", 20)
    title_font = pygame.font.SysFont("Courier New", 24, True)

    # --- Colors ---
    BG = (10, 20, 30)
    CODE_BG = (20, 35, 50)
    TXT = (220, 220, 220)
    KEYWORD_C = (0, 150, 255)
    FUNC_C = (220, 220, 100)
    COMMENT_C = (0, 150, 0)
    POLL_C = (255, 255, 0, 100) # Polling highlight
    FPGA_C = (0, 255, 120)
    FB_C = (200, 80, 255)
    CMD_C = (255, 100, 50)

    # --- Layout Rectangles ---
    SCRIPT_R = pygame.Rect(50, 50, 500, h - 100)
    FPGA_R   = pygame.Rect(SCRIPT_R.right + 100, 50, w - SCRIPT_R.right - 200, 250)
    FB_R     = pygame.Rect(FPGA_R.x, FPGA_R.bottom + 50, FPGA_R.width, h - 100 - FPGA_R.height - 50)

    # --- Python Script To Display ---
    # We add color hints directly to the script data
    script_lines = [
        ("while game_running:", KEYWORD_C),
        ("    # --- Main Game Loop ---", COMMENT_C),
        ("    player.update()", TXT),
        ("    enemies.update()", TXT),
        (" ", TXT),
        ("    # Prepare data for hardware", COMMENT_C),
        ("    render_data = scene.get_data()", TXT),
        (" ", TXT),
        ("    fpga.process_async(render_data)", FUNC_C), # The key hardware call
        (" ", TXT),
        ("    # CPU continues other work...", COMMENT_C),
        ("    sound.update()", TXT),
        ("    network.sync()", TXT),
        (" ", TXT),
        ("    # Wait if hardware not done", COMMENT_C),
        ("    while not fpga.is_done():", KEYWORD_C),
        ("        pass", KEYWORD_C),
        (" ", TXT),
        ("    # Final composite to screen", COMMENT_C),
        ("    display.update()", TXT),
    ]
    TRIGGER_LINE = 8  # Line index that triggers the FPGA
    WAIT_LINE = 15    # Line index where polling will pause

    # --- State Machine & Control ---
    # idle -> polling -> offloading -> processing -> to_framebuffer -> complete
    state = "idle"
    progress = 0.0
    poll_line = 0
    poll_timer = 0
    
    pixel_packet = []
    def generate_packet():
        nonlocal pixel_packet
        size = FPGA_R.width // 16
        pixel_packet = [{'rect': pygame.Rect(FPGA_R.x + (i%16)*size, FPGA_R.y + (i//16)*size, size, size), 
                         'color': (random.randint(50, 200), random.randint(50, 200), random.randint(50, 200))} 
                        for i in range(16*8)]

    def draw_script(current_line):
        pygame.draw.rect(display, CODE_BG, SCRIPT_R, border_radius=10)
        pygame.draw.rect(display, KEYWORD_C, SCRIPT_R, 2, border_radius=10)
        
        # Draw polling highlight
        if state not in ['idle', 'complete']:
            highlight_y = SCRIPT_R.y + 15 + current_line * 25
            highlight = pygame.Surface((SCRIPT_R.width - 10, 25), pygame.SRCALPHA)
            highlight.fill(POLL_C)
            display.blit(highlight, (SCRIPT_R.x + 5, highlight_y))

        for i, (line, color) in enumerate(script_lines):
            line_surf = code_font.render(line, True, color)
            display.blit(line_surf, (SCRIPT_R.x + 20, SCRIPT_R.y + 20 + i * 25))

    generate_packet()
    running = True
    while running:
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT or (ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE):
                running = False
            if ev.type == pygame.KEYDOWN and ev.key == pygame.K_SPACE and state in ["idle", "complete"]:
                state = "polling"
                poll_line = 0
                poll_timer = 0
                progress = 0
                generate_packet()

        display.fill(BG)

        # --- Update State Machine ---
        if state == "polling":
            poll_timer += 1
            if poll_timer > 15: # Control polling speed
                poll_timer = 0
                poll_line += 1
                if poll_line == TRIGGER_LINE:
                    state = "offloading"
                # Pause polling if we hit the wait loop and FPGA is not done
                if poll_line == WAIT_LINE and 'processing' in state:
                    pass # effectively pauses polling
                if poll_line >= len(script_lines):
                    poll_line = len(script_lines) - 1
                    if state != 'processing': # if FPGA is done, we can complete
                        state = 'complete'

        elif state == "offloading":
            progress += 0.03
            if progress >= 1.0:
                state = "processing"
                progress = 0

        elif state == "processing":
            progress += 0.005 # FPGA processing speed
            # In parallel, the script polling continues
            if poll_line < WAIT_LINE:
                 poll_timer += 1
                 if poll_timer > 20:
                     poll_timer = 0
                     poll_line += 1
            if progress >= 1.0:
                state = "to_framebuffer"
                progress = 0
        
        elif state == "to_framebuffer":
            progress += 0.02
            if progress >= 1.0:
                state = "polling" # Let polling continue past the wait loop
                poll_line += 1 # move past 'pass'
                progress = 0

        # --- Draw Components ---
        draw_script(poll_line)
        # Draw Hardware Boxes
        pygame.draw.rect(display, FPGA_C, FPGA_R, 3, 8)
        display.blit(title_font.render("FPGA", True, FPGA_C), (FPGA_R.x + 15, FPGA_R.y + 15))
        pygame.draw.rect(display, FB_C, FB_R, 3, 8)
        display.blit(title_font.render("Framebuffer", True, FB_C), (FB_R.x + 15, FB_R.y + 15))

        # --- Animate based on state ---
        if state == 'offloading':
            start_y = SCRIPT_R.y + 20 + TRIGGER_LINE * 25
            start_pos = (SCRIPT_R.right, start_y)
            end_pos = (FPGA_R.left, FPGA_R.centery)
            pos_x = start_pos[0] + (end_pos[0] - start_pos[0]) * progress
            pygame.draw.rect(display, CMD_C, (pos_x-15, end_pos[1]-10, 30, 20), 0, 4)

        if state == 'processing':
            # FPGA processing animation
            num_pixels_to_draw = int(len(pixel_packet) * progress)
            for i in range(num_pixels_to_draw):
                pygame.draw.rect(display, pixel_packet[i]['color'], pixel_packet[i]['rect'])

        if state == 'to_framebuffer':
            start_pos, end_pos = (FPGA_R.centerx, FPGA_R.bottom), (FB_R.centerx, FB_R.top)
            pos_y = start_pos[1] + (end_pos[1] - start_pos[1]) * progress
            pygame.draw.line(display, FB_C, (start_pos[0], pos_y), (end_pos[0],pos_y), 10)

        # Draw final state in FB
        if state == 'complete' or state == 'polling' and poll_line >= WAIT_LINE:
             for p in pixel_packet: # Draw final rendered image in FB
                 r = p['rect'].move(FB_R.x - FPGA_R.x, FB_R.y - FPGA_R.y)
                 pygame.draw.rect(display, p['color'], r)

        # Instructions
        inst_text = "Press SPACE to run script" if state in ["idle", "complete"] else "Executing..."
        display.blit(title_font.render(inst_text, True, TXT), (w // 2 - 200, h - 40))

        pygame.display.update()
        clock.tick(60)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    script_driven_visualization()
