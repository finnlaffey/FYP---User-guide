import pygame

def workload_display(display):
    pygame.font.init()
    clock = pygame.time.Clock()
    width, height = display.get_size()

    font = pygame.font.SysFont("Consolas", 20, bold=True)
    title_font = pygame.font.SysFont("Consolas", 26, bold=True)

    grid_w, grid_h = 5, 4
    px_size = 20
    gap = 7
    src_x = 80
    fb_x = width - 300

    systems = [
        {"label": "GPU", "func": "pygame.display.update()", "color": (0, 255, 255), "y": 80, "delay": 20, "rate": 0, "mode": "all"},
        {"label": "FPGA", "func": "draw(x, y, color)", "color": (0, 255, 100), "y": 240, "delay": 40, "rate": 2, "mode": "packet"},
        {"label": "CPU", "func": "numpy[y][x] = color", "color": (255, 100, 50), "y": 400, "delay": 80, "rate": 6, "mode": "sequential"}
    ]

    pixel_data = []
    for sys in systems:
        pixels = []
        for y in range(grid_h):
            for x in range(grid_w):
                sx = src_x + x * (px_size + gap)
                dx = fb_x + x * (px_size + gap)
                sy = sys["y"] + y * (px_size + gap)
                pixels.append({"src": (sx, sy), "dst": (dx, sy), "progress": 0.0})
        pixel_data.append(pixels)

    step = 0
    max_steps = 600
    running = True

    def draw_arrow(surf, start, end, color):
        pygame.draw.aaline(surf, color, start, end)
        vec = pygame.math.Vector2(end) - pygame.math.Vector2(start)
        if vec.length() > 0:
            vec = vec.normalize()
            left = pygame.math.Vector2(-vec.y, vec.x) * 6
            right = pygame.math.Vector2(vec.y, -vec.x) * 6
            tip = pygame.math.Vector2(end)
            pygame.draw.polygon(surf, color, [tip, tip - vec * 12 + left, tip - vec * 12 + right])

    while running:
        display.fill((5, 5, 5))
        step += 1
        if step > max_steps:
            step = 0
            for paths in pixel_data:
                for p in paths:
                    p["progress"] = 0.0

        for i, sys in enumerate(systems):
            y = sys["y"]
            color = sys["color"]
            paths = pixel_data[i]
            mode = sys["mode"]
            label = sys["label"]

            display.blit(title_font.render(f"{label}:", True, color), (10, y - 30))
            display.blit(font.render(f">>> {sys['func']}", True, color), (src_x, y - 45))

            fb_rect = pygame.Rect(fb_x - 10, y - 10, (px_size + gap) * grid_w + 14, (px_size + gap) * grid_h + 14)
            pygame.draw.rect(display, color, fb_rect, 3, border_radius=6)
            display.blit(font.render("Framebuffer", True, color),
                         (fb_x + (grid_w * (px_size + gap)) // 2 - 55, y + grid_h * (px_size + gap) + 16))

            draw_arrow(display,
                       (src_x + 140, y + grid_h * (px_size + gap) // 2),
                       (fb_x - 30, y + grid_h * (px_size + gap) // 2),
                       color)

            if mode == "packet":
                total_packets = len(paths) // 4 + 1
                packet_index = (step // 20) % total_packets

            for j, p in enumerate(paths):
                start = sys["delay"]
                active = False

                if mode == "all":
                    active = step >= start
                elif mode == "parallel":
                    active = step >= start
                elif mode == "sequential":
                    active = step >= (start + j * sys["rate"])
                elif mode == "packet":
                    if (j // 4) == packet_index:
                        active = step >= start

                if active:
                    p["progress"] = min(1.0, p["progress"] + 0.045)

                sx, sy = p["src"]
                dx, dy = p["dst"]
                progress = p["progress"]
                cx = int(sx + (dx - sx) * progress)
                if progress >= 0.99:
                    cx = dx

                glow = tuple(min(255, c + 50) for c in color)
                pygame.draw.rect(display, glow, (cx - 1, sy - 1, px_size + 2, px_size + 2))
                pygame.draw.rect(display, color, (cx, sy, px_size, px_size), border_radius=3)
                pygame.draw.rect(display, (25, 25, 25), (cx, sy, px_size, px_size), 1)

        pygame.display.update()
        clock.tick(30)

        for event in pygame.event.get():
            if event.type in (pygame.QUIT, pygame.KEYDOWN, pygame.JOYBUTTONDOWN):
                running = False
