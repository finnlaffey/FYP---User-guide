import pygame
import numpy as np
from sys import exit
import math
import time
import psutil
import GPUtil
from scripted.workload_display import workload_display
from scripted.pause_menu import pause_menu
from scripted.utils import load_image, load_seq_image, Animation
from scripted.entities import PhysicsEntity, Player, Enemy
from scripted.tilemap import Tilemap
from scripted.tb_collision import check_rect_circle_collision

class Game:
    def __init__(self):
        pygame.init()
        pygame.joystick.init()

        # Joystick setup
        self.joystick_count = pygame.joystick.get_count()
        if self.joystick_count > 0:
            self.joystick = pygame.joystick.Joystick(0)
            self.joystick.init()
            print('Joystick connected.')
        else:
            self.joystick = None
            print('No joystick found.')

        screen_width, screen_height = 1000, 600
        self.image_pos = 50
        self.knight_pos = 50

        self.display = pygame.display.set_mode((screen_width, screen_height))
        self.screen = pygame.Surface((1000, 600))
        pygame.display.set_caption('FYP Smash')

        # Load assets
        image = pygame.image.load('graphics/PNG/summer 3/Summer3.png')
        self.scaled_image = pygame.transform.scale(image, (screen_width, screen_height - self.image_pos * 2))
        self.clock = pygame.time.Clock()

        self.assets = {
            'decor': load_seq_image('tiles/decor'), 'grass': load_seq_image('tiles/grass'), 'large_decor': load_seq_image('tiles/large_decor'), 'stone': load_seq_image('tiles/stone'),
            'player/knight': load_image('run_knight/tile000.png'), 'player/idle': Animation(load_seq_image('idle'), img_dur=8), 'player/player': Animation(load_seq_image('run_knight'), img_dur=9),
            'player/jump': Animation(load_seq_image('jump'), img_dur=9), 'player/attack': Animation(load_seq_image('attack'), img_dur=9),
            'wolf/idle': Animation(load_seq_image('wolf/idle'), img_dur=6), 'wolf/run': Animation(load_seq_image('wolf/run'), img_dur=6), 'wolf/attack': Animation(load_seq_image('wolf/attack'), img_dur=6),
        }

        # Game state variables
        self.player = Player(self, (self.knight_pos, self.knight_pos), (32, 32))
        self.tilemap = Tilemap(self, tile_size=16)
        self.movement = [0, 0]
        self.scroll = [0, 0]
        self.dead = 0

        # Diagnostics and Highlighting
        self.show_diagnostics = False
        self.collision_highlights = [] 

        self.load_level(2)

    def load_level(self, map_id):
        self.tilemap.load(f"{map_id}.json")
        self.enemies = []
        for spawner in self.tilemap.extract([('spawners', 0), ('spawners', 1)]):
            if spawner['variant'] == 0:
                self.player.pos = spawner['pos']
            else:
                self.enemies.append(Enemy(self, spawner['pos'], (32, 32)))
        self.scroll = [0, 0]
        self.dead = 0

    def run(self):
        paused = False
        while True:
            self.collision_highlights.clear()
            
            if not paused and self.dead:
                self.dead += 1
                if self.dead > 40: self.load_level(2)

            self.scroll[0] += (self.player.rect().centerx - self.display.get_width() / 2 - self.scroll[0]) / 30
            self.scroll[1] += (self.player.rect().centery - self.display.get_height() / 2 - self.scroll[1]) / 30
            render_scroll = (int(self.scroll[0]), int(self.scroll[1]))

            for event in pygame.event.get():
                if event.type == pygame.QUIT: pygame.quit(); exit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE: # Pause Menu
                        result = pause_menu(self.display, 0, 2)
                        if result is True: paused = False
                        elif result == 'workload': workload_display(self.display)
                        elif isinstance(result, int): self.load_level(result); paused = False
                    if not paused:
                        if event.key == pygame.K_LEFT: self.movement[0] = 4
                        if event.key == pygame.K_RIGHT: self.movement[1] = 4
                        if event.key == pygame.K_UP: self.player.jump()
                        if event.key == pygame.K_x: self.player.dash()
                        if event.key == pygame.K_c: self.player.attack()
                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_LEFT: self.movement[0] = 0
                    if event.key == pygame.K_RIGHT: self.movement[1] = 0
            
            self.screen.fill((0, 0, 0))
            self.screen.blit(self.scaled_image, (0, self.image_pos))
            self.tilemap.render(self.screen, offset=render_scroll)

            if not paused:
                if not self.dead:
                    self.player.update(self.tilemap, (self.movement[1] - self.movement[0], 0))
                    self.player.render(self.screen, offset=render_scroll)

                player_rect = self.player.rect()
                
                # [NEW] Store the physics rects so we can use them for both logic and debug drawing
                physics_tiles_around = self.tilemap.physics_rects_around(self.player.pos)
                
                # 1. Player vs. Tile Collisions
                for tile_rect in physics_tiles_around:
                    if player_rect.colliderect(tile_rect):
                        self.collision_highlights.append(tile_rect)

                # 2. Player vs. Enemy Collisions
                for enemy in self.enemies.copy():
                    enemy.update(self.tilemap, (0, 0))
                    enemy.render(self.screen, offset=render_scroll)
                    enemy_rect = enemy.rect()

                    if self.player.attacking and check_rect_circle_collision(enemy_rect, player_rect.centerx + (20 if not self.player.flip else -20), player_rect.centery, 25):
                        self.collision_highlights.append(enemy_rect)
                        self.enemies.remove(enemy)
                        self.player.attacking = False 
                    elif player_rect.colliderect(enemy_rect):
                        self.collision_highlights.append(player_rect)
                        self.collision_highlights.append(enemy_rect)
                        if not self.player.dashing: self.dead += 1

            # --- Final Blit to Display and Universal Highlight Rendering ---
            self.display.blit(pygame.transform.scale(self.screen, self.display.get_size()), (0, 0))

            # =============================================================
            #          NEW SUPER DEBUGGER: VISUALIZE ALL RECTS
            # =============================================================
            # Create a temporary surface for drawing transparent shapes
            debug_surf = pygame.Surface(self.display.get_size(), pygame.SRCALPHA)

            # 1. Draw BLUE outlines for all tiles being checked
            if not paused:
                for tile_rect in physics_tiles_around:
                    render_rect = tile_rect.move(-render_scroll[0], -render_scroll[1])
                    pygame.draw.rect(debug_surf, (0, 100, 255, 200), render_rect, 1) # Blue outline
            
            # 2. Draw PINK highlight for tiles that are actually colliding
            for rect in self.collision_highlights:
                render_rect = rect.move(-render_scroll[0], -render_scroll[1])
                pygame.draw.rect(debug_surf, (255, 100, 200, 100), render_rect) # Pink fill

            # 3. Draw YELLOW outline for the player's hitbox
            if not paused:
                player_render_rect = player_rect.move(-render_scroll[0], -render_scroll[1])
                pygame.draw.rect(debug_surf, (255, 255, 0), player_render_rect, 1) # Yellow outline
            
            # Blit the debug surface onto the main display
            self.display.blit(debug_surf, (0, 0))
            # =============================================================
            
            pygame.display.update()
            self.clock.tick(60)

if __name__ == "__main__":
    Game().run()

