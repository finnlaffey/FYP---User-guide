import pygame
import numpy as np
from sys import exit
import time
import psutil
import GPUtil
from scripted.workload_display import workload_display
from scripted.pause_menu import pause_menu
from scripted.utils import load_image, load_seq_image, Animation
from scripted.entities import PhysicsEntity, Player, Enemy
from scripted.tilemap import Tilemap


class Game:
    def __init__(self):
        pygame.init()
        pygame.joystick.init()

        self.joystick_count = pygame.joystick.get_count()
        if self.joystick_count > 0:
            self.joystick = pygame.joystick.Joystick(0)
            self.joystick.init()
            print('yes control')
        else:
            self.joystick = None
            print('no control')

        screen_width, screen_height = 1000, 600
        self.image_pos = 50
        self.knight_pos = 50

        self.display = pygame.display.set_mode((screen_width, screen_height))
        self.screen = pygame.Surface((1000, 600))
        pygame.display.set_caption('FYP Smash')

        image = pygame.image.load('graphics/PNG/summer 3/Summer3.png')
        self.scaled_image = pygame.transform.scale(image, (screen_width, screen_height - self.image_pos * 2))
        self.floor = pygame.Surface((screen_width, self.image_pos))
        self.clock = pygame.time.Clock()

        self.assets = {
            'decor': load_seq_image('tiles/decor'),
            'grass': load_seq_image('tiles/grass'),
            'large_decor': load_seq_image('tiles/large_decor'),
            'stone': load_seq_image('tiles/stone'),
            'player/knight': load_image('run_knight/tile000.png'),
            'player/idle': Animation(load_seq_image('idle'), img_dur=8),
            'player/player': Animation(load_seq_image('run_knight'), img_dur=9),
            'player/jump': Animation(load_seq_image('jump'), img_dur=9),
            'player/attack': Animation(load_seq_image('attack'), img_dur=9),
            'wolf/idle': Animation(load_seq_image('wolf/idle'), img_dur=6),
            'wolf/run': Animation(load_seq_image('wolf/run'), img_dur=6),
            'wolf/attack': Animation(load_seq_image('wolf/attack'), img_dur=6),
        }

        self.player = Player(self, (self.knight_pos, self.knight_pos), (32, 32))
        self.tilemap = Tilemap(self, tile_size=16)
        self.movement = [False, False]
        self.scroll = [0, 0]
        self.dead = 0

        self.show_diagnostics = False
        self.last_input_time = None

        self.load_level(2)

    def load_level(self, map_id):
        self.tilemap.load(f"{map_id}.json")
        self.enemies = []
        for spawner in self.tilemap.extract([('spawners', 0), ('spawners', 1)]):
            if spawner['variant'] == 0:
                self.player.pos = spawner['pos']
            else:
                self.enemies.append(Enemy(self, spawner['pos'], (32, 32)))

        self.scroll = [0, 0]
        self.dead = 0

    def run(self):
        paused = False
        while True:
            if not paused and self.dead:
                self.dead += 1
                if self.dead > 40:
                    self.load_level(0)

            self.scroll[0] += (self.player.rect().centerx - self.display.get_width() / 2 - self.scroll[0]) / 30
            self.scroll[1] += (self.player.rect().centery - self.display.get_height() / 2 - self.scroll[1]) / 30
            render_scroll = (int(self.scroll[0]), int(self.scroll[1]))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        result = pause_menu(self.display, 0, 2)
                        if result is True:
                            paused = False
                        elif result == 'workload':
                            workload_display(self.display)
                        elif isinstance(result, int):
                            self.load_level(result)
                            paused = False

                    if event.key == pygame.K_w:
                        self.show_diagnostics = not self.show_diagnostics

                    if not paused:
                        if event.key == pygame.K_LEFT:
                            self.movement[0] = 4
                            self.last_input_time = time.time()
                        if event.key == pygame.K_RIGHT:
                            self.movement[1] = 4
                            self.last_input_time = time.time()
                        if event.key == pygame.K_UP:
                            self.player.jump()
                            self.last_input_time = time.time()
                        if event.key == pygame.K_x:
                            self.player.dash()
                            self.last_input_time = time.time()

                if event.type == pygame.KEYUP:
                    if event.key == pygame.K_LEFT:
                        self.movement[0] = 0
                    if event.key == pygame.K_RIGHT:
                        self.movement[1] = 0

                if self.joystick:
                    if event.type == pygame.JOYBUTTONDOWN:
                        if event.button == 0 and not paused:
                            self.player.jump()
                            self.last_input_time = time.time()
                        if event.button == 1 and not paused:
                            self.player.dash()
                            self.last_input_time = time.time()
                        if event.button == 7:
                            result = pause_menu(self.display, 0, 2)
                            if result is True:
                                paused = False
                            elif result == 'workload':
                                workload_display(self.display)
                            elif isinstance(result, int):
                                self.load_level(result)
                                paused = False

            if self.joystick and not paused:
                axis_value = self.joystick.get_axis(0)
                if axis_value < -0.3:
                    self.movement = [1, 0]
                    self.last_input_time = time.time()
                elif axis_value > 0.3:
                    self.movement = [0, 1]
                    self.last_input_time = time.time()
                else:
                    self.movement = [0, 0]

            self.screen.fill((0, 0, 0))
            self.screen.blit(self.scaled_image, (0, self.image_pos))
            self.tilemap.render(self.screen, offset=render_scroll)

            if not paused:
                if not self.dead:
                    self.player.update(self.tilemap, (self.movement[1] - self.movement[0], 0))
                    self.player.render(self.screen, offset=render_scroll)

                for enemy in self.enemies.copy():
                    kill = enemy.update(self.tilemap, (0, 0))
                    enemy.render(self.screen, offset=render_scroll)
                    if kill:
                        self.enemies.remove(enemy)

                    if self.player.rect().colliderect(enemy.rect()) and self.player.dashing < 40:
                        self.dead += 1

            self.display.blit(pygame.transform.scale(self.screen, self.display.get_size()), (0, 0))

            if self.show_diagnostics:
                fps = self.clock.get_fps()
                cpu_usage = psutil.cpu_percent()
                try:
                    gpus = GPUtil.getGPUs()
                    gpu_usage = gpus[0].load * 100 if gpus else 0
                except:
                    gpu_usage = 0

                current_time = time.time()
                if self.last_input_time is not None:
                    latency = (current_time - self.last_input_time) * 1000
                    latency_str = f"Input Latency: {latency:.1f} ms"
                else:
                    latency_str = "Input Latency: N/A"

                font = pygame.font.SysFont(None, 24)
                info_lines = [
                    f"FPS: {fps:.2f}",
                    f"CPU Usage: {cpu_usage:.1f}%",
                    f"GPU Usage: {gpu_usage:.1f}%",
                    latency_str,
                ]

                for i, line in enumerate(info_lines):
                    text_surface = font.render(line, True, (255, 255, 255))
                    self.display.blit(text_surface, (10, 10 + 25 * i))

            pygame.display.update()
            pixels = pygame.surfarray.array3d(self.display)
            pixels = np.transpose(pixels, (1, 0, 2))

            self.clock.tick(60)


Game().run()
